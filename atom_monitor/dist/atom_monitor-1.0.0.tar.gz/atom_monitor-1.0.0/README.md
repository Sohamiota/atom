# Atom - System Health Monitor

A comprehensive system health monitoring tool developed by Times Internet Limited.

## Installation

```bash
pip install atom-monitor
```
